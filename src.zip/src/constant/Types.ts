const TYPES = {
    Userservice : 'UserService',
    PatnerService:'PatnerService',
    UserRepository : 'UserRepository',
    PatnerRepository:'PatnerRepository'
}

export default TYPES;
