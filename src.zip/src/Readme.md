# Microservice developed on top of Typescript,Javascript,Es6,Node.js,Express Framework,InversifyJS Framework.

#platform
NODE_ENV,Typescript
Node version >22.11.0
Git

#EVIAN BACKEND :

# This  Microservice is to serve all functionalities of Evian Backend.

