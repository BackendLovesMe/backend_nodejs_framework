const TYPES = {
    Userservice : 'UserService',
    PatnerService:'PatnerService',
    UserRepository : 'UserRepository',
    PatnerRepository:'PatnerRepository',
    LoginService:"LoginService",
    LoginRepository:"LoginRepository"
}

export default TYPES;
